The data in this zip file were published in 2018 by the Geophysical Researh Letters Journal in an article tiled "An Updated Solar Cycle 25 Prediction with AFT: The Modern Minimum", which was written by Lisa A. Upton and David H. Hathaway.
 
This zip file should containt the following documents:

*** The three Figures that were published in "An Updated Solar Cycle 25 Prediction with AFT: The Modern Minimum":
Jan2016Predictions_new.png (Figure 1)
SouthernRelapseSmall.png (Figure 2)
Jan2018Predictions_new.png(Figure 3)

*** The data used in the above figures consists of four parameters which use the    
fileFormat='(i5,f8.3,f8.3,f8.3)'. The parameters are in order:
   CR -- Carrington Rotation Number of the Date
   Dipole  -- The Axial Dipole moment of the Sun's polar fields 
   North -- The polar field strength in the Northern hemisphere as measured above 55 degrees in latitude.
   South -- The polar field strength in the Southern hemisphere as measured below -55 degrees in latitude.

*** These data are available in the following files
--- AFTBaselineMDI.txt --- Measurements of the polar fields from the AFT Baseline (Version 4) assimilating magnetic data from the SOHO/MDI magnetograms.
--- AFTBaselineHMI.txt --- Measurements of the polar fields from the AFT Baseline (Version 4) assimilating magnetic data from the SDO/HMI magnetograms.
--- 2016SimSet##.txt --- Measurements of the polar fields from 32 AFT Prediction simulations shown in Figure 1 and published by: Hathaway, D. H., and L. A. Upton (2016), Predicting the amplitude and hemispheric asymmetry of solar cycle 25 with surface flux transport, Journal of Geophysical Research (Space Physics), 121, 10, doi:10.1002/2016JA023190.
--- 2018SimSet##.txt --- Measurements of the polar fields from 10 new AFT Prediction simulations simulations shown in Figure 3.

L.A.U. was supported by the National Science Foundation Atmospheric and Geospace Sciences Postdoctoral Research Fellowship Program (Award Number:1624438) and is hosted by the High Altitude Observatory at National Center for Atmospheric Research (NCAR). NCAR is sponsored by the National Science Foundation.

A complete file list is as follows:
2016SimSet01.txt
2016SimSet02.txt
2016SimSet03.txt
2016SimSet04.txt
2016SimSet05.txt
2016SimSet06.txt
2016SimSet07.txt
2016SimSet08.txt
2016SimSet09.txt
2016SimSet10.txt
2016SimSet11.txt
2016SimSet12.txt
2016SimSet13.txt
2016SimSet14.txt
2016SimSet15.txt
2016SimSet16.txt
2016SimSet17.txt
2016SimSet18.txt
2016SimSet19.txt
2016SimSet20.txt
2016SimSet21.txt
2016SimSet22.txt
2016SimSet23.txt
2016SimSet24.txt
2016SimSet25.txt
2016SimSet26.txt
2016SimSet27.txt
2016SimSet28.txt
2016SimSet29.txt
2016SimSet30.txt
2016SimSet31.txt
2016SimSet32.txt
2018SimSet01.txt
2018SimSet02.txt
2018SimSet03.txt
2018SimSet04.txt
2018SimSet05.txt
2018SimSet06.txt
2018SimSet07.txt
2018SimSet08.txt
2018SimSet09.txt
2018SimSet10.txt
AFTBaselineHMI.txt
AFTBaselineMDI.txt
Jan2016Predictions_new.png
Jan2018Predictions_new.png
Readme.txt
SouthernRelapseSmall.png